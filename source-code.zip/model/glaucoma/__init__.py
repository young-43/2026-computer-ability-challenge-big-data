"""Reproducible glaucoma competition pipeline."""
